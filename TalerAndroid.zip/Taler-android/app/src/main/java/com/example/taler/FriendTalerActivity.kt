package com.example.taler

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class FriendTalerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_friend_taler)
    }
}