package com.example.taler

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.taler.databinding.ActivityCharacterCustomBinding

class CharacterCustomActivity : AppCompatActivity() {
    private lateinit var viewBinding: ActivityCharacterCustomBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding =ActivityCharacterCustomBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        viewBinding.btnNext.setOnClickListener{
            val intent = Intent(this,MyTalerActivity::class.java)
            startActivity(intent)
        }
    }
}